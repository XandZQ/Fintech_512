from cfg import f

def test_2_1_1():
    #assert f(2,1,1) == 16
    #f(2,4,5)
    f(4,0,0)
    #f(4,7,3)
