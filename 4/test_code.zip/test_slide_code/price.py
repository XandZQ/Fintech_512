def calculate_price(stock_price, num_items, discount):
    quantity_discount = 0.0
    result = 0.0

    if num_items >= 10:
        quantity_discount = 15;
    elif num_items >= 5:          
        quantity_discount = 10;
    else:
        quantity_discount = 0

    if discount > quantity_discount:
        quantity_discount = discount

    result = stock_price/100.0 * (100-quantity_discount) * num_items;

    return result;

calculate_price(0,5,10)
#calculate_price(0,10,10)
#calculate_price(0,1,10)
