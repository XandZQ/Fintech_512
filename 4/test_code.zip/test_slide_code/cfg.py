def f(b,x,y):
    a = x + y
    z = 0
    if (b < 4):
        z = f(a,b,x)
    q = a + z
    if a > 3:
        q = q - 2
    else:
        q = q + 3
    return q

