import pytest
import requests

from unittest.mock import patch, MagicMock
from datetime import date
from stockquote import StockQuote  
from alphavantage_interface import load_stock_quotes  

def mock_response():
    return {
        "Time Series (Daily)": {
            "2024-02-02": {
                "1. open": "150.00",
                "2. high": "155.00",
                "3. low": "149.00",
                "4. close": "152.00",
                "5. volume": "1000000"
            },
            "2024-02-01": {
                "1. open": "148.00",
                "2. high": "151.00",
                "3. low": "147.00",
                "4. close": "150.00",
                "5. volume": "900000"
            }
        }
    }

@patch("requests.get")
@patch("os.getenv", return_value="fake_api_key")  # Mock environment variable
def test_load_stock_quotes(mock_getenv, mock_requests_get):
    mock_response_obj = MagicMock()
    mock_response_obj.status_code = 200
    mock_response_obj.json.return_value = mock_response()
    mock_requests_get.return_value = mock_response_obj
    
    quotes = load_stock_quotes("AAPL")
    
    assert len(quotes) == 2
    assert isinstance(quotes[0], StockQuote)
    assert quotes[0].quote_date == date(2024, 2, 2)
    assert quotes[0].open == 150.00
    assert quotes[0].high == 155.00
    assert quotes[0].low == 149.00
    assert quotes[0].close == 152.00
    assert quotes[0].volume == 1000000
    
    assert quotes[1].quote_date == date(2024, 2, 1)
    assert quotes[1].open == 148.00
    assert quotes[1].high == 151.00
    assert quotes[1].low == 147.00
    assert quotes[1].close == 150.00
    assert quotes[1].volume == 900000

def test_load_stock_quotes_no_api_key():
    with patch("os.getenv", return_value=""):
        with pytest.raises(Exception, match="ALPHAVANTAGE_API_KEY not established"):
            load_stock_quotes("AAPL")

@patch("requests.get", side_effect=requests.RequestException("Network error"))
@patch("os.getenv", return_value="fake_api_key")
def test_load_stock_quotes_network_error(mock_getenv, mock_requests_get):
    with pytest.raises(Exception, match="Unable to access alphavantage"):
        load_stock_quotes("AAPL")

@patch("requests.get")
@patch("os.getenv", return_value="fake_api_key")
def test_load_stock_quotes_invalid_stock(mock_getenv, mock_requests_get):
    mock_response_obj = MagicMock()
    mock_response_obj.status_code = 200
    mock_response_obj.json.return_value = {"Error Message": "Invalid API call. Please retry or visit the documentation (https://www.alphavantage.co/documentation/) for TIME_SERIES_DAILY."}
    mock_requests_get.return_value = mock_response_obj
    
    with pytest.raises(Exception, match="Unable to access alphavantage"):
        load_stock_quotes("INVALID")
        