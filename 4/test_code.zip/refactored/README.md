pytest test*
coverage run --branch -m pytest test_*

coverage report -m
coverage html