import pytest
from datetime import date
from stockquote import StockQuote 

@pytest.fixture
def stockquote1():
    sq = StockQuote(
        date(2023, 10, 5),
        100.0,
        110.0,
        107.0,
        98.0,
        10000,
        0.05
    )
    return sq

@pytest.fixture
def stockquote2():
    sq = StockQuote(
        date(2023, 10, 4),
        100.0,
        105.0,
        112.0,
        99.0,
        14300,
        0.00
    )
    return sq

@pytest.fixture
def stockquotes(stockquote1,stockquote2):
    return [stockquote1, stockquote2];

def test_initialization(stockquote1):
    assert stockquote1.quote_date == date(2023, 10, 5)
    assert stockquote1.open == 100.0
    assert stockquote1.close == 110.0
    assert stockquote1.high == 107.0
    assert stockquote1.low == 98.0
    assert stockquote1.volume == 10_000
    assert stockquote1.daily_rate_of_return == 0.05
    
        
def test_to_dict(stockquote1):
    stock_dict = stockquote1.to_dict()
    expected_keys = ["date", "open", "close", "low", "high", "volume", "daily_rate_of_return"]
    
    for key in expected_keys:
        assert key in stock_dict

    assert stock_dict["date"] == date(2023, 10, 5)
    assert stock_dict["open"] == 100.0
    assert stock_dict["close"] == 110.0
    assert stock_dict["low"] == 98.0
    assert stock_dict["high"] == 107.0
    assert stock_dict["volume"] == 10_000
    assert stock_dict["daily_rate_of_return"] == 0.05

def test_from_dict():
    # Using a sample dictionary with string date
    sample_dict = {
        "date": "2023-10-05",
        "open": 100.0,
        "close": 105.0,
        "high": 107.0,
        "low": 98.0,
        "volume": 10000,
        "daily_rate_of_return": 0.05
    }
    
    stockquote = StockQuote.from_dict(sample_dict)
    assert type(stockquote) is StockQuote
    assert stockquote.open == 100.0
    assert stockquote.close == 105.0
    assert stockquote.low == 98.0
    assert stockquote.high == sample_dict["high"] # probably better
    assert stockquote.volume == sample_dict["volume"]
    
        
def test_populate_daily_rate_of_return(stockquotes):   
    StockQuote.populate_daily_rate_of_return(stockquotes)
    
    # Calculate expected ROR: (110 - 105) / 105 = 0.047619...
    expected_ror = (110.0 - 105.0) / 105.0
    assert abs(stockquotes[0].daily_rate_of_return - expected_ror) < 1e-6
        
def test_empty_list_populate_daily_rate_of_return():
    StockQuote.populate_daily_rate_of_return([])
        
def test_single_item_populate_daily_rate_of_return(stockquote1):
    current_ror = stockquote1.daily_rate_of_return
    StockQuote.populate_daily_rate_of_return([stockquote1])
    assert current_ror == stockquote1.daily_rate_of_return
        
def test_invalid_order_populate_daily_rate_of_return(stockquote1, stockquote2):   
    stockquotes = [stockquote2, stockquote1]

    with pytest.raises(ValueError):
        StockQuote.populate_daily_rate_of_return(stockquotes)
            
# not testing if a close price was zero for the RoR
            
def test_convert_to_list_of_dict(stockquotes):      
    dict_list = StockQuote.convert_to_list_of_dict(stockquotes)
    assert len(dict_list) == 2
    assert type(dict_list[0]) is dict
    assert dict_list[0] == stockquotes[0].to_dict()
    
    stockquotes = StockQuote.convert_to_list_of_stockobject(dict_list)
    assert len(stockquotes) == 2
    assert type(stockquotes[1]) is StockQuote
    assert stockquotes[0].quote_date == stockquotes[0].quote_date
        
def test_save_and_load(stockquotes, tmp_path):
    file_path = tmp_path / "stockquotes.json"
    
    # Save data
    StockQuote.save_to_json(stockquotes,file_path)
    
    # Load and verify
    quotes = StockQuote.load_from_json(file_path)
    assert len(quotes) == 2
    
    quotes = StockQuote.convert_to_list_of_stockobject(quotes)
    assert type(quotes[0].quote_date) is date
        

