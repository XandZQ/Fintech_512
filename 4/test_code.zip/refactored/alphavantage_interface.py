import requests
import logging
import os
import dotenv
import sys

from stockquote import StockQuote

from datetime import date

logger = logging.getLogger(__name__)
dotenv.load_dotenv() # force this to always be loaded

def load_stock_quotes(symbol: str) -> list[StockQuote]:
    """
    Retrieves a list of StockQuote representing daily prices
    
    Args:
       symbol (str): Which stock (asset) to retreive pricing information

    Returns:
        a list of StockQuote objects, sort by date descending
        
    Raises:
    
    """
    
    api_key = os.getenv("ALPHAVANTAGE_API_KEY", None)
    if api_key is None or api_key.strip() == "":
        raise Exception("ALPHAVANTAGE_API_KEY not established")

    params = {
        "function": "TIME_SERIES_DAILY",
        "symbol": symbol,
        "apikey": api_key,
        "outputsize": "full"
    }
    logger.info(f"Calling AlphaVantage to get stock price history: {symbol}")
    try:
        response = requests.get("https://www.alphavantage.co/query", params=params)
    except Exception as ex:
        logger.info(f"Unable get stock price history: {symbol}, Exception: {ex}")
        logger.info(f"    Params: {params}")       # warning technically sensitive data with API Key
        raise Exception("Unable to access alphavantage")
        
    if response.status_code != 200 or "Time Series (Daily)" not in response.json():
        logger.info("Bad response from AlphaVantage - ")
        logger.info(f"    URL: {response.url}")       # warning technically sensitive data with API Key
        logger.info(f"    Headers: {response.headers}")
        logger.info(f"    Body: {response.text()}")
        raise Exception("Unable to access alphavantage")
    
    alphavantage_obj = response.json()
    result = []
    dates = alphavantage_obj["Time Series (Daily)"].keys()
    for d in dates:
        obj = alphavantage_obj["Time Series (Daily)"][d]
        sq = StockQuote(date.fromisoformat(d), float(obj["1. open"]), float(obj["4. close"]),
                        float(obj["2. high"]), float(obj["3. low"]), int(obj["5. volume"]))
        result.append(sq)
    
    logger.info(f"For {symbol}, retrieved {len(result)} quotes from AlphaVantage.")
    
    return result

if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        stream=sys.stderr, 
        format='%(asctime)s.%(msecs)03d %(levelname)s %(module)s/%(funcName)s: %(message)s',
        datefmt='%Y-%m-%dT%H:%M:%S', 
    )
    data = load_stock_quotes("F")
    StockQuote.populate_daily_rate_of_return(data)
    
    json_list = StockQuote.convert_to_list_of_dict(data)
    
    import pandas as pd
    print(pd.DataFrame(json_list))
    