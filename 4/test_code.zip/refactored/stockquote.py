import json
from datetime import date
from pathlib import Path

class StockQuote:
    
    def __init__(self, price_date: date, open_value: float, close_value: float,
                 high_value: float, low_value: float, volume: int, ror: float = 0.0):
        """
        Initializes a StockQuote object.

        Args:
            price_date (date): The date of the stock quote.
            open_value (float): The opening value of the stock on that day.
            close_value (float): The closing value of the stock on that day.
            high_value (float): The highest value of the stock during the day.
            low_value (float): The lowest value of the stock during the day.
            volume (int): The number of shares traded.
            ror (float, optional): Rate of return. Defaults to 0.0.
        """                 
        self.__date = price_date
        self.__open = open_value
        self.__close = close_value
        self.__high = high_value
        self.__low = low_value
        self.__volume = volume
        self.__daily_rate_of_return = ror;
    
    @property
    def quote_date(self) -> date:
        """
        Gets the date of the stock quote.

        Returns:
            date: The date of the stock quote.
        """
        return self.__date
    
    @property
    def open(self) -> float:
        """
        Gets the opening value of the stock.

        Returns:
            float: The opening value.
        """
        return self.__open
    
    @property
    def close(self) -> float:
        """
        Gets the closing value of the stock.

        Returns:
            float: The closing value.
        """
        return self.__close
    
    @property
    def high(self) -> float:
        """
        Gets the highest value of the stock during the day.

        Returns:
            float: The highest value.
        """
        return self.__high
    
    @property
    def low(self) -> float:
        """
        Gets the lowest value of the stock during the day.

        Returns:
            float: The lowest value.
        """
        return self.__low

    
    @property
    def volume(self) -> int:
        """
        Gets the trading volume of the stock.

        Returns:
            int: The number of shares traded.
        """
        return self.__volume
    
    @property
    def daily_rate_of_return(self) -> float:
        """
        Gets the daily rate of return for the stock.

        Returns:
            float: The calculated rate of return.
        """
        return self.__daily_rate_of_return
       
    def to_dict(self) -> dict:
        """
        Converts the StockQuote object into a dictionary representation.

        Returns:
            dict: A dictionary containing all the stock quote data with appropriate keys.
        """
        return {
            "date": self.quote_date,
            "open": self.open,
            "close": self.close,
            "low": self.low,
            "high": self.high,
            "volume": self.volume,
            "daily_rate_of_return": self.daily_rate_of_return
        }
        
    @staticmethod
    def from_dict(sd: dict) -> 'StockQuote':
        """
        Converts a  dictionary object into a StockQuote object.

        Args:
            sd (dict): A dictionary containing the stock quote data.

        Returns:
            StockQuote: The converted StockQuote object.
        """
        quote_date = sd["date"]
        if type(quote_date) is str:
            quote_date = date.fromisoformat(sd["date"])
        return StockQuote(quote_date, sd["open"], sd["close"], sd["high"], 
                          sd["low"], sd["volume"], sd["daily_rate_of_return"])
        
    def __repr__(self) -> str:
        """
        Provides a string representation of the StockQuote object.

        Returns:
            str: A string version of the dictionary representation.
        """
        return str(self.to_dict())
    
    def __str__(self) -> str: 
        """
        Provides a JSON formatted string of the stock quote data.

        Returns:
            str: A JSON string representing the stock quote data.
        """
        return json.dumps(self.to_dict())
    
    @staticmethod
    def populate_daily_rate_of_return(stockquotes: list):
        """
        Populates the daily rate of return for each consecutive day in a list of 
        StockQuote objects. The stock quotes must be ordered by date (descending).

        Args:
            stock_quotes (list): A list of StockQuote objects.

        Returns:
            list: The modified list with updated rates of return.

        Raises:
            ValueError: If the dates are not in descending order.
        """
        for i in range(len(stockquotes) - 1):
            if stockquotes[i].quote_date < stockquotes[i+1].quote_date:
                raise ValueError(f"Records must be in descending order. Issue at {i}")
            
            stockquotes[i].__daily_rate_of_return = (stockquotes[i].close - stockquotes[i+1].close) / stockquotes[i+1].close
            
        return stockquotes
    
    @staticmethod
    def convert_to_list_of_dict(stockquotes: list):
        """
        Converts a list of StockQuote objects into a list of dictionaries.

        Args:
            stock_quotes (list): A list of StockQuote objects.

        Returns:
            list: A list of dictionaries, each representing the data of a StockQuote.
        """
        result = []
        for sq in stockquotes:
            result.append(sq.to_dict())
        return result
    
    @staticmethod
    def convert_to_list_of_stockobject(dict_stocks: list[dict]) -> list['StockQuote']:
        """
        Converts a list of dictionary objects into a list of StockQuote objects.

        Args:
            stock_dict (dict): A dictionary containing the stock quote data.

        Returns:
            StockQuote: The converted StockQuote object.
        """
        result = []
        for sd in dict_stocks:
            result.append(StockQuote.from_dict(sd))
        return result
    
    @staticmethod
    def save_to_json(stock_quotes: list, filename: str | Path):
        """
        Saves a list of stock quotes to a JSON file.

        Args:
            stock_quotes (list): A list of StockQuote objects or dictionaries.
            filename (str): The name of the output JSON file.
        """
        data = []
        for quote in stock_quotes:
            if isinstance(quote, StockQuote):
                quote = quote.to_dict();
            if isinstance(quote["date"],date):
                quote["date"] = quote["date"].isoformat()
            data.append(quote)
            
        with open(filename, 'w') as f:
            json.dump(data, f, indent=4)
    
    @staticmethod
    def load_from_json(filename: str) -> list:
        """
        Loads stock quotes from a JSON file.

        Args:
            filename (str): The name of the input JSON file.

        Returns:
            list: A list of dictionaries containing the stock quote data.
        """
        with open(filename, 'r') as f:
            return json.load(f)
                