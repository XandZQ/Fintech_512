def factorial(x):
    result = 1
    while x > 1:
        result = result * x
        x = x - 1
    return result

print (factorial(-1))
print (factorial(0))
print (factorial(1))
print (factorial(2))
print (factorial(3))
print (factorial(4))
print (factorial(5))